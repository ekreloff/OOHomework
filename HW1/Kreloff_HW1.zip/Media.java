/* Media.java
* Modified by Ethan Kreloff on January 30th, 2015
*/

abstract class Media implements Comparable<Media>
{
    protected String title;
	  public String getTitle()  { return title; }
}
