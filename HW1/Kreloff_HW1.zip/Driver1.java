/* Driver1.java
* Created by Ethan Kreloff on January 30th, 2015
*/

import java.util.*;
public class Driver1
{
  public static void main(String[] args)
  {
    System.out.println(UserUtility.createUsername("Liz", "Boese"));
  }
}
